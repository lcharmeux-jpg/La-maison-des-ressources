# Révise 5e — 2026-2027

Site statique (HTML/CSS/JavaScript), sans serveur et sans base de données.

## Tester
Ouvre `index.html` dans un navigateur.

## Mettre en ligne gratuitement
1. Crée un compte GitHub.
2. Crée un dépôt public, par exemple `revise-5e`.
3. Envoie `index.html`, `style.css` et `script.js`.
4. Dans Settings > Pages, choisis la branche `main` et le dossier `/root`.
5. GitHub Pages fournira une adresse publique.
6. Pour apparaître dans Google, ajoute ensuite le site à Google Search Console et demande l'indexation de la page d'accueil.

## Important
Le site est une base personnalisable. Les fiches de cours et les questions doivent être vérifiées avec les cours de votre établissement/enseignants avant publication.
