const subjects=[
 ["📖","Français","Nouveau programme 5e : langue, lecture, écriture et culture."],
 ["➗","Mathématiques","Nombres, calcul, géométrie, proportionnalité et raisonnement."],
 ["🏰","Histoire-Géo","Mondes médiévaux, sociétés, territoires, ressources et risques."],
 ["🧬","SVT","Le vivant, la planète, l'environnement et les sciences."],
 ["⚗️","Physique-Chimie","Matière, mouvements, énergie et signaux."],
 ["💻","Technologie","Objets techniques, conception, programmation et numérique."],
 ["🇬🇧","Anglais","Vocabulaire, grammaire, compréhension et culture."],
 ["🎨","Arts","Créer, analyser et comprendre les œuvres et les images."]
];

const questions=[
 {s:"Maths",q:"Combien font 3/4 + 1/4 ?",a:["1","3/8","4/8","2"],c:0},
 {s:"Histoire",q:"Quel espace est au cœur des échanges entre les mondes chrétien et musulman au Moyen Âge ?",a:["La Méditerranée","Le Pacifique","L'Antarctique","L'Arctique"],c:0},
 {s:"Géo",q:"Quelle ressource est explicitement étudiée comme une ressource à ménager ?",a:["L'eau","L'or uniquement","Le sable uniquement","Le charbon uniquement"],c:0},
 {s:"SVT",q:"Quel gaz est indispensable à la respiration humaine ?",a:["Dioxygène","Hélium","Hydrogène","Néon"],c:0},
 {s:"Anglais",q:"What is the plural of 'child'?",a:["children","childs","childes","childrens"],c:0}
];
let xp=Number(localStorage.getItem("xp")||0), best=Number(localStorage.getItem("best")||0), streak=Number(localStorage.getItem("streak")||0);
let qi=0, score=0;

function updateStats(){document.querySelector("#xp").textContent=xp;document.querySelector("#heroScore").textContent=xp+" XP";document.querySelector("#best").textContent=best;document.querySelector("#streak").textContent=streak}
function renderSubjects(list=subjects){document.querySelector("#subjects").innerHTML=list.map((x,i)=>`<button class="subject" onclick="subjectInfo(${i})"><span class="icon">${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></button>`).join("")}
function subjectInfo(i){const x=subjects[i];alert(`${x[1]} — 5e\\n\\n${x[2]}\\n\\nLe contenu peut être enrichi avec tes fiches de cours et les chapitres de ton professeur.`)}
function loadQuiz(){const q=questions[qi];document.querySelector("#quizSubject").textContent=q.s;document.querySelector("#progress").textContent=`${qi+1} / ${questions.length}`;document.querySelector("#question").textContent=q.q;document.querySelector("#feedback").textContent="";document.querySelector("#next").hidden=true;document.querySelector("#answers").innerHTML=q.a.map((a,i)=>`<button class="answer" onclick="answer(${i})">${a}</button>`).join("")}
function answer(i){const q=questions[qi], buttons=[...document.querySelectorAll(".answer")];buttons.forEach(b=>b.disabled=true);if(i===q.c){buttons[i].classList.add("correct");document.querySelector("#feedback").textContent="✅ Bonne réponse ! +20 XP";xp+=20;score++;streak++;}else{buttons[i].classList.add("wrong");buttons[q.c].classList.add("correct");document.querySelector("#feedback").textContent="❌ Pas tout à fait. La bonne réponse est affichée.";streak=0}best=Math.max(best,score);localStorage.setItem("xp",xp);localStorage.setItem("best",best);localStorage.setItem("streak",streak);updateStats();document.querySelector("#next").hidden=false}
document.querySelector("#next").onclick=()=>{qi=(qi+1)%questions.length;if(qi===0){score=0;alert("Quiz terminé ! Recommence pour améliorer ton score.");}loadQuiz()};
document.querySelector("#search").oninput=e=>renderSubjects(subjects.filter(x=>x[1].toLowerCase().includes(e.target.value.toLowerCase())));
function startMemory(){const area=document.querySelector("#gameArea");area.hidden=false;let vals=["📐","📐","🌍","🌍","🧪","🧪","📚","📚"].sort(()=>Math.random()-.5);area.innerHTML=`<h3>🧠 Mémo express</h3><p>Retrouve toutes les paires.</p><div class="memory">${vals.map((v,i)=>`<button onclick="flip(this,'${v}')">?</button>`).join("")}</div>`;window.mem=[]}
function flip(el,v){if(el.classList.contains("open"))return;el.textContent=v;el.classList.add("open");mem.push(el);if(mem.length===2){if(mem[0].textContent===mem[1].textContent){xp+=10;updateStats();mem=[]}else{const a=mem;setTimeout(()=>{a.forEach(x=>{x.textContent="?";x.classList.remove("open")});mem=[]},650)}}}
function startFlash(){const area=document.querySelector("#gameArea");area.hidden=false;const facts=["La Terre tourne autour du Soleil.","L'eau bout toujours à 50°C.","Le dioxygène est présent dans l'air.","La Révolution française commence en 1789."];let n=0;function next(){let f=facts[n%facts.length], truth=n!==1;area.innerHTML=`<h3>⚡ Vrai ou faux</h3><p style="font-size:22px"><b>${f}</b></p><button class="button" onclick="vf(${truth})">Vrai</button> <button class="button" onclick="vf(${!truth})">Faux</button>`}window.vf=(ok)=>{if(ok){xp+=15;updateStats();area.innerHTML+="<p>✅ Bien joué !</p>"}else area.innerHTML+="<p>❌ Essaie encore !</p>";n++;setTimeout(next,700)};next()}
function startNumber(){const area=document.querySelector("#gameArea");area.hidden=false;const a=Math.floor(Math.random()*20)+2,b=Math.floor(Math.random()*12)+2;area.innerHTML=`<h3>🔢 Défi calcul</h3><p style="font-size:24px"><b>${a} × ${b} = ?</b></p><input id="calc" type="number" style="padding:12px;border:1px solid #ddd;border-radius:10px"> <button class="button" onclick="checkCalc(${a*b})">Valider</button><p id="calcFeedback"></p>`;window.checkCalc=(ans)=>{const v=Number(document.querySelector("#calc").value);document.querySelector("#calcFeedback").textContent=v===ans?"✅ Correct ! +15 XP":"❌ Réessaie.";if(v===ans){xp+=15;updateStats()}}}
renderSubjects();updateStats();loadQuiz();
